import { Component, OnInit, inject } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

export interface Task {
  id: number;
  title: string;
  description: string;
  endDate: string;
  priority: number;
  status: 'To do' | 'In progress' | 'Completed';
  shared_with: any[];
}

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [DatePipe],
  templateUrl: './home-page.html',
  styleUrls: ['./home-page.scss']
})
export class HomePage implements OnInit {
  private http = inject(HttpClient);
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private datePipe = inject(DatePipe);

  public allTasks: Task[] = [];
  public todoTasks: Task[] = [];
  public inProgressTasks: Task[] = [];
  public completedTasks: Task[] = [];

  public isSidebarCollapsed = false;
  public isModalOpen = false;
  public activeCardMenu: number | null = null;
  
  public taskForm!: FormGroup;
  public editingTask: Task | null = null;

  private apiUrl = 'http://localhost/organizr/backend/tasks'; 

  ngOnInit(): void {
    this.loadTasks();
    this.initTaskForm();
  }

  loadTasks(): void {
    const token = localStorage.getItem('authToken');
    if (!token) {
      this.router.navigate(['/login']);
      return;
    }
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    this.http.get<Task[]>(this.apiUrl, { headers }).subscribe({
      next: (tasks) => {
        this.allTasks = tasks;
        this.organizeTasks();
      },
      error: (err) => {
        console.error('Erro ao carregar tarefas', err);
        if (err.status === 401) this.router.navigate(['/login']);
      }
    });
  }

  organizeTasks(): void {
    this.todoTasks = this.allTasks.filter(t => t.status === 'To do');
    this.inProgressTasks = this.allTasks.filter(t => t.status === 'In progress');
    this.completedTasks = this.allTasks.filter(t => t.status === 'Completed');
  }

  initTaskForm(): void {
    this.taskForm = this.fb.group({
      title: ['', Validators.required],
      description: [''],
      endDate: [this.datePipe.transform(new Date(), 'yyyy-MM-dd'), Validators.required],
      priority: [1, Validators.required],
      status: ['To do', Validators.required]
    });
  }

  openModal(task: Task | null = null): void {
    this.activeCardMenu = null;
    if (task) {
      this.editingTask = task;
      this.taskForm.setValue({
        title: task.title,
        description: task.description,
        endDate: this.datePipe.transform(task.endDate, 'yyyy-MM-dd'),
        priority: task.priority,
        status: task.status
      });
    } else {
      this.editingTask = null;
      this.taskForm.reset({
        endDate: this.datePipe.transform(new Date(), 'yyyy-MM-dd'),
        priority: 1,
        status: 'To do'
      });
    }
    this.isModalOpen = true;
  }

  closeModal(): void {
    this.isModalOpen = false;
  }

  onSaveTask(): void {
    if (this.taskForm.invalid) return;

    const taskData = this.taskForm.value;
    const request = this.editingTask
      ? this.http.put(`${this.apiUrl}/${this.editingTask.id}`, taskData)
      : this.http.post(this.apiUrl, taskData);

    request.subscribe({
      next: () => {
        this.loadTasks();
        this.closeModal();
      },
      error: (err) => console.error('Erro ao salvar tarefa', err)
    });
  }

  deleteTask(id: number): void {
    if (confirm('Tem a certeza que quer apagar esta tarefa?')) {
      this.http.delete(`${this.apiUrl}/${id}`).subscribe({
        next: () => this.loadTasks(),
        error: (err) => console.error('Erro ao apagar tarefa', err)
      });
    }
  }

  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }

  toggleCardMenu(taskId: number): void {
    this.activeCardMenu = this.activeCardMenu === taskId ? null : taskId;
  }

  logout(): void {
    localStorage.removeItem('authToken');
    this.router.navigate(['/login']);
  }
}