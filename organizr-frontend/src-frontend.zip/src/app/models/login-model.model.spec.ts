import { LoginModel } from './login-modelmodel';

describe('LoginModel', () => {
  it('should create an instance', () => {
    expect(new LoginModel()).toBeTruthy();
  });
});
