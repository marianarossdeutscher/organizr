export class LoginModel {
    constructor (
        email: string,
        password: string
    ) {}
}
