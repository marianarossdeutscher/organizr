<?php
namespace Src\Controllers;

use Src\Services\UserService;

class UserController {
    private UserService $service;

    public function __construct()
    {
        $this->service = new UserService();
    }

    /**
     * Lista todos os usuários.
     */
    public function index(): void {
        header('Content-Type: application/json');
        echo json_encode($this->service->list());
    }

    /**
     * Lista os dados de um usuário pelo id.
     */
    public function show(int $id): void {
        header('Content-Type: application/json');
        echo json_encode($this->service->getUserById($id));
    }

    /**
     * Cria um novo usuário.
     */
    public function create(): void
    {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true) ?? [];

        try {
            $task = $this->service->create($data);
            http_response_code(201);
            echo json_encode($task);
        } catch (\Exception $e) {
            http_response_code(400);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Atualiza os dados de um usuário existente.
     *
     * @param int $id
     */
    public function update(int $id): void
    {
        $username      = $_GET['username']      ?? null;
        $email         = $_GET['email']         ?? null;
        $password_hash = $_GET['password_hash'] ?? null;

        $user = [
            'id'            => $id,
            'username'      => $username,
            'email'         => $email,
            'password_hash' => $password_hash
        ];

        try {
            $updated = $this->service->update($id, $user);
            echo json_encode($updated);
        } catch (\RuntimeException $e) {
            http_response_code(404);
            echo json_encode(['error' => $e->getMessage()]);
        } catch (\InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Exclui um usuário pelo ID.
     *
     * @param int $id
     * @return bool
     * @throws \RuntimeException Se usuário não for encontrado
     */
    public function delete(int $id): bool 
    {
        $user = $this->service->delete($id);
        if (!$user) {
            throw new \RuntimeException("Usuário com ID {$id} não encontrado.");
        }
        return $this->service->delete($id);
    }
}